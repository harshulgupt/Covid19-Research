Model Visualizer software: https://github.com/lutzroeder/netron

Dataset link: https://data.mendeley.com/datasets/9xkhgts2s6/2

VGG16 Model in keras link: https://keras.io/api/applications/vgg/#vgg16-function
